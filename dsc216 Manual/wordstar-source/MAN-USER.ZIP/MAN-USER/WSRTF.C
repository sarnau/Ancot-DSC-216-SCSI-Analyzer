
// filename : wsrtf.c
//   author : David Chester <david_chester@yahoo.com>
//  created : January 2002
//  version : 0.2
//   purpse : a utility to conver WS 5.x and 6.x documents to RTF

#include <stdio.h>
#define TRUE 1
#define FALSE 0

#define BUF_SIZE 20

FILE *in;
FILE *out;
FILE *header;
FILE *errFile;
int a, b, c, i, j;
char line[1024];
int isInCode = FALSE;  // boolean to see if we are in a ws-formatting sequence
int isInUline = FALSE;
int isInBold = FALSE;
int col = 0, row = 0;
char dotCode[100];
float dotArg;
int lMarg = 0;
int spCount = FALSE, tabToggle = FALSE;
int inBody = FALSE;
int chsCode = 0;  // characters through ws code
char outName[128];
int inCenter;
int footerAlready = FALSE;
char buf[BUF_SIZE];
int inSentence = FALSE;
int lineBreakAt = 0;
int hardRetBuf = 0;
int newPage;
int pastHeader = FALSE;
int inTab;
int codeLen;
int sectionSym = FALSE;
int dataLoss = FALSE;
int midSentence = FALSE;
int newMarg = FALSE;
int rMarg;
unsigned char degreeSym = FALSE;

jumpOut() {

    while(a = fgetc(in) != 29) {
        if (a == EOF) {
            printf("\nFile error. Premature end-of-file.\n");
            return(2);
        }
    }
#ifdef DEBUG
    fprintf(out, "(jumped) END CODE");
#endif
    isInCode = 0;
    return 1;
    pastHeader = TRUE;
}

jumpLine() {

    while (TRUE) {

        a = fgetc(in);
        if (a == 10) break;

        if (a == EOF) {
            printf("\nFile error. Premature end-of-file.\n");
            return(2);
        }

        if (a == 29) {
            isInCode = TRUE;
            codeLen = fgetc(in);
            break;
        }

        c = b;
        b = a;
    }
    return 1;
}



float getFloat(char a[]) {

    int bIndex = 0;
    char b[10];
    int i;
    float val;

    for(i=0; i<strlen(a); i++)
        if (a[i] >= '0' && a[i] <='9' || a[i] == '.')
            b[bIndex++] = a[i];

    if (b[bIndex - 1] == '.')
        b[bIndex++] = 0;

    b[bIndex] = '\0';

    sscanf(b, "%f", &val);

    return val;
}


main(int argc, char *argv[]) {

    if(argc < 2 || argc > 3) {
        printf("\n WSRTF Converts a Wordstar 5.x or 6.x file into Rich Text Format (RTF). \n");
        printf("\n      Usage: WSRTF <filename>\n\n");
        return(2);
    }

    strcpy(outName, argv[1]);
    strcat(outName, ".rtf");

    in = fopen(argv[1], "rb");
    out = fopen(outName, "wt");
    header = fopen("header.rtf", "rt");

    if (in == NULL) {
        printf("\n  ERROR: Couldn't access input file.\n");
        return(7);
    }

    if (out == NULL) {
        printf("\n  ERROR: Couldn't create output file.\n");
        return(7);
    }

    printf("  Creating %s ", outName);

                                                                        // header

    fprintf(out, "{\\rtf1\\ansi\\ansicpg1252\\deff0\\deflang1033{\\fonttbl{\\f0\\fcharset0 Times New Roman;}}\n");

    while ((a = fgetc(in)) != EOF) {

        //
        //      INSIDE WS CONTROL CODE
        //

        if (isInCode) {

            isInCode++;

            if ((a >= 32 && a < 128) && \
                (b >= 32 && b < 128) && \
                (c >= 32 && c < 128) && inBody && isInCode) {

                    fputc(c, out);
                    fputc(b, out);
                    fputc(a, out);

                    dataLoss =  TRUE;
                    fprintf(out, " ## WSRTF ERROR: Possible loss of data. ## ");

                    isInCode = 0;

            }



            if (a == 29 && codeLen <= isInCode - 2 ) {

                if(pastHeader && !inBody)
                    hardRetBuf++;

                isInCode = 0;
                pastHeader = TRUE;

            }


            if (codeLen == 32 && b == 0 && a == 11) {        // page breaks
                jumpOut();
                col = 0;
                row = 0;
                inBody = FALSE;
                newPage = TRUE;
                printf(".");
            }

            if (codeLen == 10 && b == 0 && a == 9) {        // alignment

                for(i=0; i<5; i++)
                    a = fgetc(in);

                isInCode += 5;

                if (a == 33)                                 // center
                    inCenter = TRUE;

                if (a == 93)                                  // right
                    fprintf(out, "\\pard\\qr ");

                if (a == 32) {
                    if (col > 1) {
                        fprintf (out, "\\par\n\\par\n\\tab\\tab ");     //tab
                        //if (lMarg) fprintf (out, "\\tab *7*");
                    }
                    else inTab++;
                }
            }

#ifdef DEBUG
            fprintf(out, " %d ", a);
#endif
        } else {

            //
            //      OUTSIDE OF WS CONTROL CODE
            //

            if (a == 29) {
                isInCode = TRUE;
                codeLen = fgetc(in);
            }

            if (a == 27) {                          // extended characters
                a = fgetc(in);

                if (a == 21) {
                    if(col) fprintf(out, " \\'a7");
                    else sectionSym = TRUE;
                    col++;
                    spCount = 0;
                }


                if (a == 248) {
                    if(col) {
                        fprintf(out, " \\'b0");
                        col++;
                    }
                    else degreeSym = TRUE;
                    spCount = 0;
                }

                fgetc(in);
            }



            if (a == 9)                             // tab
                fprintf (out, "\\tab ");

            if (col == 0 && a == '.') {             // dot codes

                for(i=0; i<100; i++)
                    dotCode[i] = '\0';

                for (i=0; i<100; i++) {

                    a = fgetc(in);

                    if (a == 29)
                        jumpOut();

                    if (a == 10) {
                        col = 0;
                        break;
                    }

                    if (a >=32 && a < 128)
                        dotCode[i] = a;
                }

                                                                    // left margin
                if ((dotCode[0]=='l' || dotCode[0]=='L') && \
                    (dotCode[1]=='m' || dotCode[1]=='M'))  {

                    dotArg = getFloat(dotCode);
                    lMarg = 1426 * dotArg;
                    if (lMarg < 0) lMarg = 0;
                    newMarg = TRUE;

                 }                                              // right margin

                /*if ((dotCode[0]=='r' || dotCode[0]=='R') && \
                    (dotCode[1]=='m' || dotCode[1]=='M'))  {

                    dotArg = getFloat(dotCode);
                    rMarg = 1426 * dotArg;
                    if (rMarg < 0) lMarg = 0;
                    newMarg = TRUE;

                 }*/

                if ((dotCode[0]=='p' || dotCode[0]=='P') && \
                    (dotCode[1]=='a' || dotCode[1]=='A'))  {
                    fprintf(out, "\\page ");
                    row = 0;
                    col = 0;
                    inBody = 0;
                }

            }

                                                // page numbering

            if (row >= 38 && inCenter && ((a == 'p' || a =='P') || (a >= '0' && a <= '9'))) {

                inCenter = FALSE;

                if ((a == 'p' || a == 'P') && !footerAlready) {
                    fprintf(out, "\n{\\footer \\pard\\plain \\qc Page {\\field{\\*\\fldinst { PAGE  \\\\* CardText  \\\\* MERGEFORMAT }}{\\fldrslt {\\lang1024\\langfe1024\\noproof default}}}{ of }");
                    fprintf(out, "\n{\\field{\\*\\fldinst { NUMPAGES \\\\* CardText \\\\* MERGEFORMAT }}{\\fldrslt {\\lang1024\\langfe1024\\noproof default }}} \\par } ");
                    footerAlready = TRUE;
                }

                if ((a >= '0' && a <= '9') && !footerAlready) {
                    fprintf(out, "\n{\\footer \\pard\\plain \\qc {\\field{\\*\\fldinst { PAGE  \\\\* MERGEFORMAT }}{\\fldrslt {\\lang1024\\langfe1024\\noproof default }}} \\par } ");
                    footerAlready = TRUE;
                }

                jumpLine();

            }


            if ((b == '.' || b == ';' || b==':' || b == ',') && (a == ' ' || a == 13 || a == 10))
                midSentence = FALSE;

            if (b != 141 && a == 10 && col < 30)
                midSentence = FALSE;

            if (a > 31 && a < 128) {        // printing characters

                col++;

                if (c == '(' && ((b >= 'a' && a <= 'z') || (b >= '0' && b <= '9')))
                    midSentence = TRUE;

                if (hardRetBuf && newPage && a >= 'a' && a <= 'z') {
                    fprintf(out, " ");
                    newPage = FALSE;        // page breaks and hard returns
                    hardRetBuf = 0;

                } else {

                    if (hardRetBuf) {

                        for (i=0; i<hardRetBuf; i++)
                            fprintf(out, "\\par\n\\pard ");

                        if (lMarg) {
                            fprintf(out, "\\li%d ", lMarg);
                            newMarg = FALSE;
                        }

                        if (rMarg)
                            fprintf(out, "\\ri%d ", rMarg);

                        if(inTab) {

                            if(!midSentence) {
                                for (i=0; i<inTab; i++) {

                                    fprintf(out, "\\tab ", col, lMarg);
                                    if (lMarg && col < 5)
                                        fprintf(out, "\\tab ");
                                    col += 5;
                                }

                                inTab = FALSE;

                            }
                            else
                                fprintf(out, " ");

                            inTab = FALSE;
                        }
                        if (isInBold)
                            fprintf(out, "\\b ");

                        if(isInUline)
                            fprintf(out, "\\ul ");

                        if(inCenter) {
                            inCenter = FALSE;
                            fprintf(out, "\\pard\\qc ");
                        }

                        if(sectionSym) {
                            fprintf(out, " \\'a7");
                            sectionSym = FALSE;
                        }

                        if(degreeSym) {
                            fprintf(out, " \\'b0");
                            degreeSym = FALSE;
                        }


                        col = 0;
                        row++;
                        spCount = 0;
                        tabToggle = FALSE;
                        hardRetBuf = 0;
                    }
                }

                if (a == ' ') {

                    spCount++;

                    if (spCount > 3)
                        tabToggle = TRUE;

                } else {

                    if(tabToggle) {

                        if (spCount > 12 && spCount < 30)
                            spCount += (80-spCount) * .1;

                        for(i=0; i<spCount; i+=5) // 3-5 spaces becomes tab
                            if (!midSentence) {

                                fprintf(out, "\\tab ");

                                if (lMarg && col < 5)
                                    fprintf(out, "\\tab ");
                            }

                        spCount = 0;
                        tabToggle = FALSE;

                    }



                    if(spCount) {
                        for(i=0; i<spCount; i++)
                            fputc(' ', out);
                        spCount = 0;
                    }

                    inBody = TRUE;
                    fputc(a, out);
                    col++;
                }
            }

           if (a == 19) {                 // underline

                if (!isInUline) {
                    isInUline = TRUE;
                    if (col) fprintf(out, " \\ul ");
                } else {
                    isInUline = FALSE;
                    fprintf(out, "\\ul0 ");
                }
            }

            if (a == 2) {                     // bold

                if (!isInBold) {
                    isInBold = TRUE;
                    fprintf(out, "\\b ");
                } else {
                    isInBold = FALSE;
                    fprintf(out, "\\b0 ");
                }
            }


#ifdef DEBUG
            else
                fprintf (out, "%d  ", a);
#endif


                                                        // end of file
            if (c == 26 && b == 26 && a == 26)
                goto bailout;

                                                        // hard returns

            if (((b == 13 && a == 10) || (b != 141 && a == 10)) && inBody && !midSentence) {

                hardRetBuf++;

                    col = 0;
                    row++;
                    spCount = 0;
                    tabToggle = FALSE;
                    inCenter = FALSE;
            }

            if (b != 141 && a == 10 && inBody && midSentence)
                fprintf(out, " ");

            if (b == 141 && a == 10) {      // soft returns
                fprintf(out, "\n");
                col = 0;
                row++;
                inCenter = FALSE;
            }

        }

        c = b;
        b = a;

    }

bailout:

    fprintf(out, "\\par\n}\n");

    fclose(in);
    fclose(out);


    if (dataLoss)
        printf(" ERROR: Possible loss of data.");
    else
        printf(" Done.\n");

    return(0);

}

